const 
db={ the: { chunks: ['th', 'e'], phones: ['DH', 'AH'] }, 
of: { chunks: ['o', 'f'], phones: ['AH', 'V'] },
 }; 
 export default db;